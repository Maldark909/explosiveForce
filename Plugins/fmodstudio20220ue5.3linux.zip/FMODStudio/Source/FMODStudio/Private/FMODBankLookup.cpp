#include "FMODBankLookup.h"

UFMODBankLookup::UFMODBankLookup(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
    , DataTable(nullptr)
{}