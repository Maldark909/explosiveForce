// Copyright (c), Firelight Technologies Pty, Ltd. 2023-2023.

#include "FMODAudioLinkLog.h"

DEFINE_LOG_CATEGORY(LogFMODAudioLink);