The FMODStudio plugin can be placed in the Engine/Plugins directory, or in your game's GameName/Plugins directory.

Please see this page for more instructions:
    https://fmod.com/docs/2.02/unreal
